import axios from 'axios';

var events = []
axios.get('http://localhost:5000/api/schedule')
.then(res => {
  events = res[0]
  console.log(res[0])
})

export default events