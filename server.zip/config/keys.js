module.exports = {
  mongoURI: `mongodb+srv://lav:lav123@petzglobal.1q0du.mongodb.net/users?retryWrites=true&w=majority`,
  secretOrKey: "secret"
};
