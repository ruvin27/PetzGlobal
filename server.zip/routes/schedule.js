const express = require('express');
const scheduler = express.Router();

const Schedule = require('../models/schedule');

scheduler.get('/', (req,res) => {
    Schedule.find()
    .then(appointments => res.json(appointments));
})

module.exports = scheduler
